//CS101 Assignment 4 - Fall 2022
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


// TODO: Add function prototypes here

double get_bet_amount(double bet, double money);
int get_bet_type();
int get_number();
int spin_wheel();
double evaluate_odd(int rolled, double bet);
double evaluate_even(int rolled, double bet);
double evaluate_number(int number, int rolled, double bet);
void print_winnings(double money, double start);

int main(void) {
  double money, start, bet, change;
  int type, number, rolled;
  int keep_playing = 1;

  printf("Enter the amount of money you are starting with: ");
  scanf("%lf", &money);
  start = money;

  while(keep_playing == 1)
  {
	  //Add code here
     

  
  
  }
  return 0;
}


// TODO: Add function code here

double get_bet_amount(double bet, double money)
{
  int can_bet = 0;
  //Add code here
  
  
    return bet;
}


int get_bet_type()
{
  int roulette_type;
 //Add code here
 
 
  return roulette_type;

}


int get_number()
{
  int n;
  
  //Add code here
  
  return n;
}


int spin_wheel()
{
srand(time(0));
int n = rand() % 37;
return n;
}


double evaluate_odd(int rolled, double bet)
{
  //Add code here
}


double evaluate_even(int rolled, double bet)
{
  //Add code here
}


double evaluate_number(int number, int rolled, double bet)
{
  //Add code here
}


void print_winnings(double money, double start)
{
  //Add code here
}